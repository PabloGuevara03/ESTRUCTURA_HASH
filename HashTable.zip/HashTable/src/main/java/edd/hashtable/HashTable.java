package edd.hashtable;

public class HashTable {
    // La tabla hash se implementa como un array de listas enlazadas.
    // Cada elemento del array (cubeta o bucket) contendrá una lista de pares clave-valor
    // para manejar colisiones (encadenamiento separado).
    private Entry[] table;
    private int capacity; // Capacidad inicial de la tabla hash

    /**
     * Clase interna que representa una entrada en la tabla hash.
     * Cada entrada contiene una clave, un valor y una referencia a la siguiente entrada
     * en caso de colisión (para la lista enlazada).
     */
    private static class Entry {
        Object key;
        Object value;
        Entry next; // Referencia a la siguiente entrada en la misma cubeta

        public Entry(Object key, Object value) {
            this.key = key;
            this.value = value;
            this.next = null; // Inicialmente, no hay siguiente entrada
        }
    }

    /**
     * Constructor de la tabla hash.
     * @param capacity La capacidad inicial de la tabla hash (número de cubetas).
     */
    public HashTable(int capacity) {
        if (capacity <= 0) {
            throw new IllegalArgumentException("La capacidad debe ser mayor que cero.");
        }
        this.capacity = capacity;
        this.table = new Entry[capacity]; // Inicializa el array de cubetas
    }

    /**
     * Función hash simple para calcular el índice de la cubeta para una clave dada.
     * Utiliza el método hashCode() de la clave y el operador módulo (%)
     * para asegurar que el índice esté dentro de los límites de la tabla.
     * @param key La clave para la que se calculará el índice.
     * @return El índice de la cubeta donde se almacenará la clave.
     */
    private int hash(Object key) {
        // Aseguramos que el valor absoluto del hashCode para manejar claves con hashCode negativo
        return Math.abs(key.hashCode() % capacity);
    }

    /**
     * Inserta un par clave-valor en la tabla hash.
     * Si la clave ya existe, actualiza su valor.
     * @param key La clave a insertar.
     * @param value El valor asociado a la clave.
     */
    public void put(Object key, Object value) {
        if (key == null || value == null) {
            throw new IllegalArgumentException("La clave y el valor no pueden ser nulos.");
        }

        int index = hash(key); // Calcula el índice de la cubeta

        // Recorre la lista enlazada en la cubeta para buscar la clave
        Entry current = table[index];
        while (current != null) {
            if (current.key.equals(key)) {
                // Si la clave ya existe, actualiza el valor y termina
                current.value = value;
                return;
            }
            current = current.next;
        }

        // Si la clave no existe, crea una nueva entrada y la agrega al principio de la lista
        Entry newEntry = new Entry(key, value);
        newEntry.next = table[index]; // La nueva entrada apunta a la antigua primera entrada
        table[index] = newEntry;      // La nueva entrada se convierte en la primera de la cubeta
    }

    /**
     * Recupera el valor asociado a una clave en la tabla hash.
     * @param key La clave cuyo valor se desea recuperar.
     * @return El valor asociado a la clave, o null si la clave no se encuentra.
     */
    public Object get(Object key) {
        if (key == null) {
            throw new IllegalArgumentException("La clave no puede ser nula.");
        }

        int index = hash(key); // Calcula el índice de la cubeta

        // Recorre la lista enlazada en la cubeta para buscar la clave
        Entry current = table[index];
        while (current != null) {
            if (current.key.equals(key)) {
                // Si la clave se encuentra, devuelve su valor
                return current.value;
            }
            current = current.next;
        }

        // Si la clave no se encuentra en la cubeta, devuelve null
        return null;
    }

    /**
     * Elimina un par clave-valor de la tabla hash.
     * @param key La clave del par a eliminar.
     * @return El valor asociado a la clave eliminada, o null si la clave no se encuentra.
     */
    public Object remove(Object key) {
        if (key == null) {
            throw new IllegalArgumentException("La clave no puede ser nula.");
        }

        int index = hash(key); // Calcula el índice de la cubeta

        Entry current = table[index];
        Entry previous = null; // Para mantener un seguimiento de la entrada anterior

        while (current != null) {
            if (current.key.equals(key)) {
                // Si la clave se encuentra
                if (previous == null) {
                    // Si es la primera entrada de la cubeta, actualiza la cabecera
                    table[index] = current.next;
                } else {
                    // Si no es la primera, enlaza la entrada anterior con la siguiente
                    previous.next = current.next;
                }
                return current.value; // Devuelve el valor de la entrada eliminada
            }
            previous = current; // Actualiza la referencia a la entrada anterior
            current = current.next; // Avanza a la siguiente entrada
        }

        // Si la clave no se encuentra, devuelve null
        return null;
    }

    /**
     * Clase principal para probar la implementación de la tabla hash.
     */
    public static void main(String[] args) {
        System.out.println("Creando una tabla hash con capacidad de 10.");
        HashTable myHashTable = new HashTable(10);

        System.out.println("\nInsertando elementos:");
        myHashTable.put("nombre", "Juan");
        myHashTable.put("edad", 30);
        myHashTable.put("ciudad", "Madrid");
        myHashTable.put("profesion", "Ingeniero");
        myHashTable.put("nombre", "Pedro"); // Actualiza el valor de "nombre"

        System.out.println("Valor de 'nombre': " + myHashTable.get("nombre")); // Debería ser Pedro
        System.out.println("Valor de 'edad': " + myHashTable.get("edad"));
        System.out.println("Valor de 'ciudad': " + myHashTable.get("ciudad"));
        System.out.println("Valor de 'profesion': " + myHashTable.get("profesion"));
        System.out.println("Valor de 'pais' (no existe): " + myHashTable.get("pais"));

        System.out.println("\nEliminando elementos:");
        System.out.println("Eliminando 'edad': " + myHashTable.remove("edad")); // Debería devolver 30
        System.out.println("Valor de 'edad' después de eliminar: " + myHashTable.get("edad")); // Debería ser null

        System.out.println("Eliminando 'pais' (no existe): " + myHashTable.remove("pais")); // Debería devolver null

        System.out.println("\nInsertando más elementos para probar colisiones (si es que se producen):");
        myHashTable.put("clave1", "valor1");
        myHashTable.put("clave2", "valor2"); // Estas pueden colisionar dependiendo de la implementación de hashCode()
        myHashTable.put("clave3", "valor3");

        System.out.println("Valor de 'clave1': " + myHashTable.get("clave1"));
        System.out.println("Valor de 'clave2': " + myHashTable.get("clave2"));
        System.out.println("Valor de 'clave3': " + myHashTable.get("clave3"));
    }
}